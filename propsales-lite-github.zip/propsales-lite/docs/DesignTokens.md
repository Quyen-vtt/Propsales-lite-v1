# PropSales Lite — Token màu (bổ sung cho DXS Partner Web Admin Design System)

**Bảng màu chốt: A · Chàm tĩnh (23/09).** Trung tính nhuộm cùng hue với brand: `ink` #101A3D · `ink-2` #26365F · `mut` #5A6785 · `line` #DEE3F2 · `bg` #F3F5FC · `surface-blue` #EBEFFF. Semantic trầm: `ok` #148F6E (on-tint #0B6B51) · `warn` #8F5A10 / tint #FFF3E0 · `danger` #C8425A (on-tint #A83349) · `orange` #E89B3C. Badge đặc: ok #0F7A5C · warn #B06A12 · danger #C8425A · slate #6B7A99. Phương án B (Xanh & san hô) và C (Đêm chàm) đã bỏ.

**Chip lọc đang chọn (chốt):** nền `surface-blue`, viền rgba(81,124,255,.55), chữ `brand-text`, số `brand-deep`; ô màu có vòng viền brand. Không dùng màu đặc cho trạng thái chọn — màu đặc dành cho nút chính và ô "Đang mở bán".

**Select:** mũi tên tự vẽ (chevron 14px, stroke #5A6785) cách mép phải 12px, padding-right 34px.


Cập nhật 23/09/2026. Thay nhóm màu thương hiệu DXS (navy #023278 → xanh #1069C5 → cyan #13AEF9) bằng họ xanh PropSales Lite gốc **#517CFF**. Các token trung tính, trạng thái (ok/warn/danger), bo góc, bóng, chữ giữ nguyên theo file DXS.

## 1. Họ màu thương hiệu

| Token | Hex | Tương phản trên trắng | Dùng ở đâu |
|---|---|---|---|
| `brand` | **#517CFF** | 3,7 : 1 | Màu nhận diện: nav active (gradient), viền focus, icon, ô "Đang mở bán" khi không mang chữ nhỏ, đầu sáng của gradient. **Không** dùng làm chữ nhỏ trên trắng và không đặt chữ trắng nhỏ lên nó (chưa đạt AA 4,5). |
| `brand-strong` | #3B63E8 | 5,1 : 1 | Nền đặc có chữ trắng nhỏ: nút chính, ô căn "Đang mở bán", đầu tối của gradient nút. |
| `brand-text` | #2F55D4 | 6,2 : 1 | Link, tên dự án hover, chữ nhấn màu brand trên nền trắng / tint. |
| `brand-deep` | #1F3AA6 | 9,7 : 1 | Chip đang chọn, avatar, logo mark, chữ trên `surface-blue`. |
| `sky` | #8FB0FF | — | Điểm sáng gradient nền, viền/tint phụ. Không dùng cho chữ. |
| `surface-blue` | #EAEFFF | — | Tint xanh 12 %: nền badge đếm, nút toggle đang chọn, ô số liệu. |

Gradient: `--grad-brand: linear-gradient(135deg, #3B63E8 0%, #517CFF 100%)` (nav active, nút brand).
Logo mark: `linear-gradient(135deg, #1F3AA6, #517CFF)`.
Bóng: `--sh-resting: 0 4px 14px rgba(81,124,255,.06)` · `--sh-emphasis: 0 8px 20px rgba(81,124,255,.14)` · `--sh-brand-btn: 0 4px 16px rgba(81,124,255,.34), inset 0 1px 0 rgba(255,255,255,.45)`.
Nền trang: mesh hai lớp `rgba(81,124,255,.14)` góc trên-trái và `rgba(143,176,255,.16)` góc trên-phải trên `#F2F7FB` — bỏ lớp cam của DXS.

## 2. Màu cam
Cam DXS `#F78D23` / `#AD6318` không còn là màu thương hiệu; chỉ giữ với nghĩa **cảnh báo / đang chờ** (`warn`, `warn-tint`) và một sắc trong lớp "Đang giao dịch" của bảng hàng.

## 3. Màu trạng thái căn (bảng hàng) — theo 5 lớp
| Lớp | Trạng thái hệ thống | Hex |
|---|---|---|
| Chưa mở bán | Chưa mở bán | #E3E9F0 · chữ #56687F |
| Đang mở bán | Đang mở bán | `brand-strong` #3B63E8 · chữ trắng · quầng `rgba(81,124,255,.3)` 2px |
| Đang giao dịch | ĐVBH đã đăng ký GD → ĐVBH đã xác nhận → Đang kiểm tra hồ sơ | #FFE8C2 → #FFC466 → #F78D23 |
| Đã bán | Chuyển cọc thành công → Hợp đồng | #0E9F6E → #0A6B4B · chữ trắng |
| Ngoài rổ | Khóa đầu tư · Thanh lý · Đổi tên/Chuyển nhượng · Đã chuyển CTBH | gạch chéo #C9D4E0/#EEF2F6 · #8FA6BC (gạch ngang) · #6F86A0 · #C9D4E0 |

## 4. Chữ trên nền tint (bổ sung AA, giữ từ bản 22/09)
`ok-on-tint` #0A7350 · `warn-on-tint` #96550E · `danger-on-tint` #B33D49.

## 5. Tên gọi
Sản phẩm: **PropSales Lite**. Vai trò vận hành nền tảng trong prototype đổi từ "PropHub" → "PropSales" (CSKH PropSales duyệt bài đăng & đơn nhận bán). Tên miền tham chiếu bản thật vẫn là apps.prophub.vn.

## 6. Shell — hai lớp (chốt 23/09, khác DXS)
DXS dùng một khối glass nổi cách mép 20px, bo 22px, sidebar + main chung khối. PropSales Lite đổi sang **hai lớp**:
- **Lớp 1 — mặt phẳng nền**: `body` gradient chéo 160° `#F2F5FB → #EDF1F8 → #E8EDF6` (24/09, đậm một bậc so với bản 23/09 `#F8F9FD → #F0F3FA`), phủ hai vệt sáng `rgba(81,124,255,.11)` (góc trên-trái) và `rgba(143,176,255,.12)` (góc dưới-phải). Sidebar **trong suốt**, không viền, không nền riêng — thuộc lớp này. Ô tìm kiếm sidebar `rgba(255,255,255,.55)`.
- **Lớp 2 — khối nội dung**: `.main` bo 22px, cách mép 12px (trên/phải/dưới), nền `#FFFFFF → #FBFCFE`, viền `rgba(255,255,255,.9)`, bóng `0 8px 24px rgba(31,58,166,.045), 0 1px 2px rgba(31,58,166,.03)`. Header nằm trong khối, phẳng, viền dưới `--line`. Card có viền `rgba(31,58,166,.06)` để tách khỏi nền khối.
- Bảng màu B: nền kem `#FAF9F6 → #F1F0EB`, vệt san hô 7%. Bảng màu C: nền navy `#0B1E5B → #1E3A9F`, khối nội dung sáng, bóng đen 35%.
- Đã thử và bỏ: sidebar gradient đặc, sidebar kính mờ tách nền, header bo góc nổi riêng.

### 6b. Bốn bậc trong khối nội dung (chốt 23/09)
| Bậc | Thành phần | Nền / viền |
|---|---|---|
| L2 | Khối nội dung + header | #FFFFFF; header ngăn bằng viền dưới `--line` |
| L2.5 | Vùng làm việc `.view` | #F4F6FB (B: #F6F5F1 · C: #F2F4FA) |
| L3 card | Thanh ngữ cảnh, Block, panel căn, bảng, form, KPI, thẻ lệnh/thẻ tải nhập | #FFFFFF **không viền** (24/09, Quyen: "không muốn stroke ở card") + bóng mềm `0 1px 2px rgba(31,58,166,.04), 0 6px 18px rgba(31,58,166,.05)`; hover thẻ bấm được: bóng nâng `0 12px 28px rgba(81,124,255,.10)`. Panel trống: viền đứt rgba(31,58,166,.14) (outline) |
| L3 control | Ô tìm, select, chip, cửa, nút phụ | #FFFFFF + viền mỏng, không bóng |
| L4 | Menu, toast | Bóng 0 14px 34px rgba(31,58,166,.16) |

## 7. Trạng thái "đang chọn" — một ngữ pháp chung (chốt 23/09)
Nguyên tắc: **tint + viền/gạch brand, không tô đặc**. Dải/nền chứa (không phải trạng thái chọn) nằm trực tiếp trên vùng làm việc xám thì dùng xám xanh đậm hơn một bậc để không chìm. Màu đặc chỉ dành cho nút chính, ô căn "Đang mở bán" và số đếm của tab đang chọn.

| Thành phần | Mặc định | Đang chọn |
|---|---|---|
| Chip lọc `.lg` | trắng, viền rgba(31,58,166,.06), chữ `ink-2` | nền `surface-blue`, viền rgba(81,124,255,.55) + inset 1px .25, chữ `brand-text`, số `brand-deep` |
| Nhóm lớp đang xổ `.lg-group.opened` | dải trắng, viền inset rgba(31,58,166,.10), bo 12px — chỉ làm khung nhóm, không mang màu | chip lớp bên trong = tint + viền brand như mọi chip; trạng thái con trong suốt, con chọn = tint + viền. Đã thử và bỏ: dải tint, dải xám xanh, cả dải thành chip lớn (23/09). |
| Tab phân đoạn `.tabs` (Thẻ/Bảng, vai trò) | trong suốt, chữ `--mut` 500 | nền `surface-blue`, chữ `brand-deep` 700 |
| Tab phụ `.subtabs` (YCĐCH/YCĐCO/GD; Tải nhập/Lịch sử/SP/Giá) | chữ `--mut` 600, số đếm nền #EEF1F7 chữ `--mut` | nền `surface-blue` bo trên 10px, chữ `brand-text` 700, gạch dưới 2.5px `brand` vẽ bằng `box-shadow: inset 0 -2.5px 0` (không dùng pseudo-element để không bị overflow cắt), số đếm nền `brand-strong` chữ trắng |
| Menu sidebar (2 cấp, 24/09) | cấp 1 chữ `ink` 600, cấp 2 chữ `ink-2` 500; hover nền trắng .6 | **fill gradient brand (`--grad-brand`), chữ & icon trắng, số đếm trắng mờ — áp cho cả hai cấp** (Quyen chọn giữ fill như ban đầu, 24/09). Sidebar là ngoại lệ duy nhất được tô đặc cho trạng thái chọn. Nhóm đang mở / đang chứa màn active: chỉ đổi chữ + icon sang `brand-text`, không nền. Mục "sắp có": chữ `mut`, nhãn viền mảnh. |
| Select | viền `--line`, chữ `--mut` khi placeholder | `.filled`: chữ `ink`, viền rgba(81,124,255,.45), nền `surface-blue` nhạt |

## 8. Bảng dữ liệu `.tbl-wrap` (chốt 23/09)
- Bo góc **18px** (nhỏ hơn card 22px), cắt góc bằng `clip-path: inset(0 round 18px)` để Safari vẫn bo khi bảng cuộn ngang; 2 ô đầu/cuối của `thead` bo theo; hàng cuối bỏ viền dưới.
- Nền trắng L3, viền 1px rgba(31,58,166,.07), bóng 0 1px 2px .04. Header `thead` nền `--bg`, chữ `--mut` 600 12px.

## 9. Kiểm tra đồng bộ (23/09)
- Toàn bộ `var(--*)` được dùng đều có định nghĩa trong `:root`; `--sky`, `--orange-text` định nghĩa nhưng chưa dùng (giữ lại).
- Đã gỡ: bảng màu trạng thái PropHub cũ (`.pal-old`), gradient bìa bản DXS, viền đứt #A8C6E6, skeleton #EDF3F9 → dùng token.
- Còn giữ có chủ ý ngoài bảng token: #F78D23 (sắc 3 lớp "Đang giao dịch"), 3 gradient bìa `.cv-b/c/d` (fallback khi dự án không có ảnh), màu lớp căn ở mục 3.
- 10 màn đã chạy Playwright không lỗi JS: Dự án · Bảng hàng (+ mở lớp trạng thái) · Yêu cầu & giao dịch (2 tab) · Thiết lập (4 tab) · Điều hành sự kiện.

## 10. Sidebar (24/09)
- 2 cấp, accordion; rộng 262px; cây tính năng đầy đủ, mục chưa dựng có nhãn "sắp có" (toast khi bấm); khu "Bản đầy đủ · sắp có" tắt/mở bằng ô tick ở chân.
- Active (cả 2 cấp): fill `--grad-brand`, chữ/icon trắng, số đếm trắng mờ. Nhóm đang mở hoặc chứa màn active: chữ + icon `brand-text`, không nền.
- **Thu gọn**: nút ‹ › cạnh logo, nhớ trong `localStorage` (`psl.sidebar.collapsed`). Rail 72px: icon 19px trong ô 44×44 bo 12px, số đếm → chấm 8px (brand / cam) góc trên-phải, nhãn nhóm & ô tìm ẩn (ô tìm thành nút, bấm sẽ mở rộng và focus). Bấm icon nhóm → flyout L4 bên phải (tiêu đề nhóm uppercase + danh sách con, con active fill gradient); Esc / bấm ngoài đóng. Hover có tooltip (title).

## 11. Ô màu lớp trạng thái (chốt 24/09 — phương án B)
- Lớp một trạng thái: ô vuông 12×12 bo 4px.
- Lớp nhiều trạng thái: **viên dọc rời, khe 1px, cả cụm luôn rộng 17px** — viên giãn đều theo số trạng thái (3 viên ≈ 5px, 2 viên = 8px); đầu trái/phải bo 4px. Luôn vẽ đủ viên theo định nghĩa lớp (tối đa 3), kể cả trạng thái = 0, để mỗi lớp cùng hình dạng ở mọi dự án.
- Đã thử và bỏ: viên 5px cố định (Đã bán hẹp hơn các lớp khác), chấm tròn chồng, cột bậc thang, ô vuông chia dải; chỉ vẽ trạng thái có dữ liệu (gây "Ngoài rổ" còn 1 viên mảnh ở THE PRIVE').

## 12. Dọn design system (24/09 tối)

Mục tiêu: gọn code, không đổi giao diện. Kiểm bằng so ảnh 23 trạng thái (1440px và 1280px): 0 điểm ảnh khác, trừ sidebar (cỡ chữ chuẩn hoá).

**Token mới** (thay cho mã màu viết cứng):

| Token | Giá trị | Dùng cho |
|---|---|---|
| `line-soft` | #EEF1F7 | Nền đếm số trên tab phụ, vạch chia nhẹ |
| `line-strong` | #CBD3EA | Viền đậm hơn `line` (ô trống, nét đứt) |
| `mut-2` | #9AA6C4 | Chữ/icon phụ nhạt hơn `mut` (placeholder, "sắp có") |
| `violet` / `violet-tint` | #5B43C4 / #EFEAFF | Nhóm "Hợp đồng" trong thông báo |
| `fw-num` | 750 | Số lớn hiển thị (KPI, mã căn, giá) |

**Đã sửa:**
- `brand-deep` thống nhất #1F3AA6 (tài liệu trước ghi #1E3A9F).
- 33 mã màu viết cứng → `var(--token)` (brand, brand-strong, brand-deep, sky, mut, ink-2, orange, ok…).
- Bỏ 248 khai báo bị rule sau cùng selector ghi đè, xoá 68 rule rỗng — CSS 118 KB → 111 KB.
- `!important` 44 → 22 (chỉ bỏ chỗ bỏ đi không đổi ảnh).
- Sidebar: cỡ chữ lẻ 13.2 / 12.8 / 12.6px → 13 / 12.5px.

**Thang cỡ chữ đang dùng:** 10 · 10.5 · 11 · 11.5 · 12 · 12.5 · 13 · 13.5 · 14 · 15 (giao diện) · 17 · 22 · 25 · 28 · 34 (số/tiêu đề). Riêng ô căn bảng hàng dày: 8.5 / 9.5px — cố ý, không dùng nơi khác.

**Đã duyệt & áp dụng (24/09 tối):**

- **Cỡ chữ** — làm tròn lên bước nguyên: 10.5→11, 11.5→12, 12.5→13, 13.5→14, 15.5→15, 16/18/19→17, 20→22, 25→28. Thang còn lại: **10** (nhãn nhóm viết hoa) · **11** · **12** · **13** · **14** · **15** · **17** · **22** · **28** · **34**; ô căn bảng hàng dày 8.5 / 9 / 9.5px (ngoại lệ). Không dùng cỡ nửa px mới.
- **Bo góc** — 4 token: `radius-tag` 6px (ô căn, tag) · `radius-chip` 11px (chip, nút nhỏ) · `radius-control` 15px (ô nhập, nút, dropdown) · `radius-card` 22px (card, panel, bảng). Ngoại lệ: ≤3px (thanh mảnh), 50% / 999px (tròn).
- **Đổ bóng** — 4 token: `sh-1` nền · `sh-2` nổi (hover/đang chọn) · `sh-3` pop-up (menu, panel, tooltip) · `sh-focus` vòng focus 3px. Giữ riêng: `sh-brand-btn` (nút chính), vòng trạng thái (ok/danger tint), viền inset chỉ báo.
- Thanh công cụ bảng hàng: 3 cửa không co (`flex-shrink:0`), hai select co giãn (min 120px) — đủ chữ ở 1440px.


## 13. Lớp tiện ích `u-*` (24/09 tối — thay style inline)

293/304 style viết thẳng trong JS đã chuyển thành class tiện ích — 152 class, cú pháp `u-<thuộc tính>-<giá trị>`:

| Tiền tố | Thuộc tính | Ví dụ |
|---|---|---|
| `d` `fd` `ai` `jc` `fwr` `gap` | display, flex-direction, align-items, justify-content, flex-wrap, gap | `u-d-flex u-fd-column u-gap-12` |
| `grow` `shrink` `minw` `maxw` `w` `h` | kích thước | `u-grow-1 u-h-36` |
| `m` `mt` `mb` `ml` `mr` `p` `pt` | lề | `u-ml-auto u-mt-12` |
| `fs` `fw` `ff` `ls` `ta` `ws` `to` | chữ | `u-fs-13 u-fw-600 u-ta-right` |
| `c` `bg` `b` `r` `sh` | màu (theo token), viền, bo góc, bóng | `u-c-mut u-bg-surface-blue` |

- Giá trị màu/bo góc/bóng trong `u-*` **chỉ trỏ token** (vd. `u-c-mut` = `color:var(--mut)`), không có mã màu riêng.
- Khối `u-*` đặt **đầu stylesheet, có `!important`**: thắng mọi rule thường (như style inline cũ), thua rule `!important` khác — giữ đúng thứ tự ưu tiên cũ. Ngoài khối này còn 27 `!important`.
- 11 style inline giữ lại có chủ đích: giá trị tính lúc chạy (`width:<pct>%` thanh tiến trình) hoặc nằm trong thuộc tính có điều kiện.
- Quy tắc cho phần làm tiếp: **không viết `style="..."` mới**. Bố cục một lần dùng `u-*`; mẫu lặp ≥ 3 lần thì đặt class có tên (vd. `.btn-quiet`, `.lexit`).
- Gộp thêm 12 selector trùng khi chứng minh được không đổi thứ tự ưu tiên; 96 selector còn lặp là do phụ thuộc thứ tự, để nguyên.
- Kiểm: so ảnh 23 trạng thái (1440/1280px) = 0 điểm ảnh khác; so computed style mọi phần tử trên 13 màn × 3 vai × mọi nút hành động (136 lần chụp) = không khác, trừ chấm nhấp nháy và ảnh lazy-load.

**Còn lại (không ảnh hưởng thiết kế):** 9 lớp bọc hàm render — logic riêng của prototype, không cần dọn cho bàn giao.

## 14. Chọn dự án trên Bảng hàng (24/09 — phương án B)

- Tên dự án trên thanh ngữ cảnh (HT PEARL và THE PRIVE') là nút `.pj-sw`: chữ + ô mũi tên `surface-blue` 26px; hover/đang mở nền `bg`; focus `sh-focus`. Phím tắt Ctrl/⌘ K khi đang ở Bảng hàng.
- Popover `.sw-pop` 420px, `radius-card`, `sh-3`: ô tìm (viền brand + `sh-focus`) → nhóm **Đã ghim** (dùng cờ ghim ở Danh sách dự án) → **Xem gần đây** (3 dự án) → **Dự án khác** (đang bán trước, sắp mở, đã kết thúc) → chân "Quản lý tất cả dự án →". Mỗi dòng: chấm trạng thái · tên · pha · thanh % 56px · số yêu cầu chờ · dấu ✓ ở dự án đang xem (nền `surface-blue`). Dự án ẩn/demo không hiện.
- Bàn phím: ↑↓ chọn, Enter mở, Esc đóng; bấm ra ngoài để đóng.
- Sidebar: "Bảng hàng" lên cấp 1 (icon bảng), active cho cả HT PEARL và THE PRIVE'; nhóm Bán hàng còn CTBH · Rổ hàng & giá · Lịch sử tải nhập.
- Tổng quan: mỗi dòng dự án có nút mũi tên `.ov-go` 28px (`surface-blue`, hover `brand-strong` chữ trắng).

## 15. Logo (24/09 — quy tắc cứng)

- Dùng **nguyên file logo Quyen gửi** (PNG nền trong suốt): không tách nền, không đổi màu, không thêm viền/stroke/bóng/bo góc/filter. Chỉ được cắt bỏ phần viền trong suốt thừa.
- Sidebar mở: bản chữ đầy đủ cao 26px. Rail thu gọn: ô biểu tượng cắt từ chính file đó, 34×34px.

## 16. V2 — Bảng hàng THE PRIVE' cùng khung HT PEARL (phương án A, 24/09)

Thứ tự hàng (giống nhau ở bản đồ toàn dự án và lưới block): **thanh ngữ cảnh** (logo TP · tên = nút chọn dự án · chọn CTBH · 3 KPI toàn dự án) → **hàng công cụ** (tìm mã căn 168px · ĐVBH · Ưu tiên · "Chỉ xem" khi Bảng hàng tổng · 3 cửa · ⋯) → **hàng chip block** 1–12 + "Toàn dự án" (đang ở bản đồ thì nút này sáng `surface-blue`) → **chú giải 5 lớp** → dòng "Đang làm nổi…" khi có lọc → nội dung.
- Lọc ĐVBH/Ưu tiên/lớp/mã căn áp cho cả bản đồ (chấm mờ `opacity .16`) và lưới (ô `.dim`); số trên chú giải đếm theo ĐVBH/Ưu tiên đang chọn. "Bỏ lọc" xoá tất cả.
- ≤1380px: chip block co đều một hàng (chữ phụ 10px), ô tìm 150px.

## 17. V2 — nhóm ưu tiên 1 sau phản hồi khách (25/09)

- **Cột chi tiết căn (chốt lại 25/09 sau góp ý Quyen)**: CỐ ĐỊNH bên phải 320px, sticky — không trượt, không đổi phía (ngăn trượt + đổi phía đã thử và bỏ). Chưa chọn căn → cột hiện: Đang chờ xử lý (3 căn ĐVBH đăng ký/xác nhận/kiểm tra hồ sơ + link tổng) · Căn vừa xem (4 gần nhất) · Căn đang mở bán; bấm mục nào là chọn căn đó trên lưới. Đã chọn căn → thứ tự: mã + trạng thái → **Ưu tiên (YCĐCH)** → nút thao tác chính → diện tích/giá → giao dịch → vòng đời trạng thái → Lịch sử. Esc bỏ chọn.
- **Lưới**: ưu tiên nhìn nhiều block cùng lúc — ô cao 24px, chữ 9,5px (THE PRIVE' 10,5px), khoảng cách 2px; HT PEARL ở 1440px ô rộng 15,5px, thấy 22/34 tầng mỗi block.
- **Không còn nút chết không lời giải thích**: 2 cửa "… đang chạy" / "Thiết lập rổ & giá" mở màn thật (Chương trình bán hàng / Rổ hàng & giá); thông báo lệnh chưa có ghi "Bản demo chưa có hộp thoại này"; thông báo thao tác thành công không kèm ghi chú. Bỏ mọi chữ "Bản dựng thử…" và mục "Xem bản đầy đủ để so".
- **Sidebar**: mặc định ẩn mục "sắp có" (bật lại bằng "Hiện tính năng bản đầy đủ").
- Chú giải trạng thái đã luôn có chữ + số — giữ nguyên; bảng màu mới giữ nguyên (chốt 25/09).
- **THE PRIVE' nhiều block cùng lúc**: số block ở màn chi tiết theo bề ngang để ô căn ≥ ~20px — 2 block (1280px), 3 (1440px), 4 (1920px); gồm block đang chọn + block đang bán gần nhất, xếp theo số. Block chính viền brand; block phụ mờ .55, chỉ xem, đổi qua "Chọn block này" hoặc chip.
- **Thanh ngữ cảnh bảng hàng (25/09)**: bỏ 3 số tổng (trùng chú giải); thanh = dự án (nút chọn) · CTBH · 3 cửa · ⋯. Hàng công cụ chỉ còn tìm mã căn + lọc ĐVBH + Ưu tiên (select tối đa 230px, không cắt chữ). Áp cho cả HT PEARL và THE PRIVE'.
- **THE PRIVE' không nhảy (25/09)**: cửa sổ block giữ nguyên khi chọn block/căn đã nằm trong đó, chỉ dịch khi chọn block ngoài cửa sổ; giữ vị trí cuộn khi chọn căn/đổi block. Mọi block đang hiện bấm chọn căn được (block đó thành block chính, nhãn "Đang chọn" + viền brand); bỏ làm mờ và bỏ link "Chọn block này".
- **Chi tiết căn (25/09)**: chip trạng thái 11,5px/600 nằm dòng riêng dưới mã căn. **Ưu tiên (YCĐCH)** mỗi ô 3 dòng: mã YC · ĐVBH / KH · TVV / giờ đăng ký + "Đã nộp giữ chỗ" hoặc "Chưa nộp tiền"; ô trống ghi "Trống — chọn YCĐCH"; đếm n/3; bấm ô để đổi YC (select ẩn phủ ô). Giá demo đầy đủ: giá chưa VAT · có VAT (10%) · tổng giá trị HĐ (gồm KPBT 2%) · tiền giữ chỗ 50 triệu · chính sách. Vòng đời trạng thái gọn thành 1 thanh 7 đoạn + "Bước x/7 · tiếp theo: …".

## 18. V2 — cột chi tiết căn & điểm nhấn thương hiệu (26/09)

- **Bảng hàng giữ hàng chip block gọn** — không dùng dải block lớn (đẩy lưới xuống, khách không chọn).
- **Cột chi tiết căn — một mép trái, một nhịp**: không lồng khung trong khung; các mục (Ưu tiên · thao tác · giá · Giao dịch · tiến độ) ngăn bằng kẻ `--line-soft` 1px; khoảng cách 14px giữa mục / 8px trong mục; tiêu đề mục 12px/700 viết hoa, màu `--mut`. Giá = danh sách dòng "nhãn trái · số phải" (số tabular, không xuống dòng; chú thích như "(10%)", "(gồm KPBT)" nằm dòng dưới nhãn).
- **Tổng quan — tâm điểm thương hiệu (phương án C)**: mảng màu thương hiệu duy nhất của trang là **sự kiện bán hàng đang chạy** (`.ov-hero`, nền dải `--brand-deep → --brand-text → --brand`, bo `--radius-card`). Nội dung: tên dự án · CTBH, pha hiện tại + đếm ngược tới pha kế, thanh 6 pha có nhãn, 4 số (YC chờ · % đã cọc · căn đang GD · căn đang mở), 2 nút (Điều hành sự kiện nền trắng / Mở bảng hàng viền trắng). Không có sự kiện → "Sự kiện tiếp theo" (dự án sắp mở gần nhất). Token chữ trên nền thương hiệu: `--on-brand`, `--on-brand-mut`, `--on-brand-line`, `--on-brand-ok`. Thẻ "Sự kiện đang chạy" ở cột phải đã bỏ (không trùng). Logo không đổi.
- Lời chào theo giờ: sáng (<11h) · trưa (<14h) · chiều (<18h) · tối.
- **Ô Ưu tiên (YCĐCH) gỡ chen chúc (26/09)**: mỗi ô chỉ một điểm đậm = tên ĐVBH (13,5px/600) + mũi tên chọn; dòng 2 "KH … · TVV …" 12px; dòng 3 "mã YC · giờ" (trái, mờ) + trạng thái dạng chấm + chữ (phải, không chip). Bỏ vạch trái và nền số đặc (số = vòng tròn 20px nền xanh nhạt). YC trúng: viền + nền xanh lá nhạt. Ô trống: viền nét đứt. Nhịp: đệm 10/12px, giữa dòng 3px, giữa ô 8px.
- **Chữ số — quy tắc cứng (26/09)**: bộ số đều (`tabular-nums`/`tnum`) của Mona Sans vẽ số 0 có gạch chéo, ở cỡ nhỏ và đậm dễ đọc nhầm thành 8 → toàn prototype dùng số tỉ lệ (`font-variant-numeric: normal`). Không bật lại `tnum`.
- **Biểu tượng "Thêm" (⋯)**: dùng icon SVG `more` (3 chấm), không dùng ký tự ⋯ (một số máy không có glyph → nút rỗng).
- **Ô Ưu tiên còn trống phải gây chú ý (26/09)**: viền đứt 1,5px màu brand, nền `--surface-blue`, dấu "+" và chữ 12,5px/600 `--brand-text`, số trong vòng viền brand; di chuột → viền liền. Tiêu đề mục hiện "Còn trống n" (chip cam `--warn-tint`) khi chưa đủ 3; đủ thì "3/3".
- **Khối giá chi tiết căn phân cấp (26/09)**: 2 nhóm có tiêu đề + icon (`tag` Giá bán · `wallet` Thanh toán, cùng kiểu tiêu đề "Ưu tiên"). Cấp chính: Giá chưa VAT K2D 24px `--brand-deep`, dưới là diện tích · đơn giá (icon `sqm`). Cấp phụ: dòng nhãn–số; **Tổng giá trị HĐ** nền `--surface-blue`, số 14px/700. Chính sách = chip. Chú thích nhãn viết đầy đủ ("Thuế 10%", "Gồm kinh phí bảo trì").
- **[TẠM HOÃN 26/09 — Quyen chưa ưng, đang dùng lại "cửa sổ block" 25/09 + màn Toàn dự án; bản thử lưu `v2_lane_try.html`]** THE PRIVE' — hàng block cố định thứ tự, bỏ màn "Toàn dự án": mở dự án vào thẳng lưới. Mọi block đang bán nằm trên MỘT hàng theo số block (K block vừa màn: 1 ở điện thoại · 2 ở 1280px · 3 ở 1024/1440px · 4 ở 1920px; còn lại cuộn ngang, snap theo block). Lưới **không bao giờ xếp lại**: bấm chip = cuộn (mượt, tối thiểu) tới block đó + viền block nháy 1,2s; ← → trên bàn phím đi block kế. Chip block đang thấy trọn có gạch chân 3px, chip vừa chọn tô nền; bên phải hàng chip "‹ Đang xem Block 3–5 / 5 ›" (ẩn khi không cần cuộn). Block chưa mở gom 1 chip "6–12 · chưa mở bán" (bấm → thông báo số căn + dự kiến). Chú giải đếm cho toàn bộ block đang bán (đúng với cái hàng block đang chứa). Tiêu đề trang chỉ "Bảng hàng". Giữ vị trí cuộn khi chọn căn.
- **Nút màu thương hiệu (26/09)**: không có viền sáng phía trên — `--sh-brand-btn` bóng đổ xanh sáng `0 8px 20px -4px rgba(86,132,255,.6), 0 2px 6px -1px rgba(86,132,255,.28)`; nền = `--grad-brand-glass` (kính nhẹ: dải sáng trắng 20%→0 mờ dần từ trên, không viền cứng + đốm sáng xanh góc dưới phải + gradient #3B63E8→#5A86FF); mục sidebar đang chọn không viền trắng.
- **[ĐÃ BỎ 26/09 — Quyen: bỏ icon không cần thiết; khối giá chỉ giữ icon ở tiêu đề nhóm Giá bán/Thanh toán, không icon từng dòng, không icon diện tích]** ~~Khối giá — icon dòng~~: mỗi dòng có icon 17px `--mut` **không nền bao** (Quyen 26/09) (`vat` Giá có VAT · `file` Tổng giá trị HĐ — nền trắng, icon brand · `coin` Tiền giữ chỗ · `gift` Chính sách). Nhãn phụ không xuống dòng ("Gồm phí bảo trì").
- **Thẻ lệnh (26/09)**: icon 20px đứng trần (không nền bao), màu brand; mô tả tối đa 2 dòng. Nhóm có trình tự (**Ráp ưu tiên**) là danh sách dọc 4 bước có đường nối: 1 Sắp xếp ưu tiên → 2 Rút thăm sản phẩm (khi trùng thứ tự) → 3 Khoá ráp ưu tiên → 4 Gửi email xác nhận ưu tiên; nhãn "Bước n" 10,5px viết hoa màu brand. Tên lệnh giữ đúng tên menu bản thật.
- **Ráp ưu tiên — danh sách bước có trạng thái (26/09, thay bản 4 thẻ trống)**: mỗi hàng = icon (nối dọc) · "Bước n" + chip trạng thái (Đã xong xanh lá / Cần làm cam / Chưa tới xám) · tên + mô tả · số liệu của bước (vd "3 căn đang trùng thứ tự", "4 ĐVBH sẽ nhận email") · nút làm 104px (bước đang làm = nút chính, còn lại nút phụ, bước chưa tới mờ). Bước đang làm có nền `--surface-blue`; bước xong icon ✓ nền xanh lá nhạt, đường nối xanh lá. Góc phải tiêu đề: "Bước 2/4". Số liệu minh hoạ.
- **Ráp ưu tiên gọn (26/09, Quyen: "hơi cồng kềnh")**: mỗi bước 1 hàng ~52px = số thứ tự trong vòng 24px (✓ khi xong, nền brand khi đang làm) · tên + số liệu của bước · chip trạng thái · nút 96px. Bỏ nhãn "Bước n" và dòng mô tả (mô tả chuyển vào tooltip). Không dùng icon riêng cho từng bước — số thứ tự đã đủ nghĩa.
- **Icon không nền bao — quy tắc toàn prototype (26/09)**: mọi icon trang trí (tiêu đề mục `.h3-ic`, thẻ số Tổng quan `.kb-ic`, việc cần xử lý `.kpi-ic`, thông báo `.nb-ic`, tệp `.file-ic`/`.io-ic`, trạng thái rỗng `.state-ic`) đứng trần, không ô/vòng nền, giữ màu theo ngữ nghĩa (brand/ok/warn/danger), cỡ 17–20px. Ngoại lệ: nút icon (`.btn-icon`, `.icon-btn`, mũi tên `.ov-go`) vẫn có vùng bấm; ảnh đại diện dự án/người (chữ viết tắt) không phải icon.
