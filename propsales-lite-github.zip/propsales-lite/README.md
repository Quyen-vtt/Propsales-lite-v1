# PropSales Lite — prototype giao diện

Prototype giao diện (retouch/redesign PropHub) cho PropSales Lite của iHouzz: Dự án · Bán hàng · Bảng hàng. Đây là bản vẽ kỹ thuật để dev tham chiếu, không gọi API thật; dữ liệu trong prototype là minh hoạ.

| Tệp | Nội dung |
|---|---|
| `index.html` | **Version 2** (đang làm) — mở trực tiếp bằng trình duyệt |
| `v1/index.html` | Version 1 (đã chốt 24/09/2026, đóng băng) |
| `docs/DesignTokens.md` | Design tokens, quy tắc giao diện và các quyết định thiết kế |

Mỗi tệp HTML là một file độc lập (CSS/JS/logo nhúng sẵn), chỉ tải font từ Google Fonts. Bật GitHub Pages (Settings → Pages → nhánh `main`, thư mục `/`) để có link xem trực tuyến.
